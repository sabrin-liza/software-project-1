Team-NeXplorers
Software Project_1: TakeRent-website(Give and take anything on rent)
Team members:
Sumyia Sabrin Liza
_221-15-5768
Swarnaly Sarker
_221-15-5943